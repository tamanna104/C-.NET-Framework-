﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pet_Addaptation
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void lblLogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            new SignIn().Show();
        }

        private void lblVeterinarian_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Veterinarian().Show();
        }

        private void lblBill_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Bill().Show();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Home().Show();
        }
    }
}
